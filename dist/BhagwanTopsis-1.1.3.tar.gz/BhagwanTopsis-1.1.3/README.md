# Topsis Package
It takes an Datafile(.csv file) as an input along with 2 more arguments(weights ,impacts) along with name for output file(.csv format) as 4th argument.
Pass as a refrences for the DataFile.
Weights and Impacts as List.

## Installation
To proudly pip install your module, fire up a terminal and run:
``Syntax :``
``pip install BhagwanTopsis``



## Importing the Package
``Syntax :``
``import BhagwanTopsis as BT``

## License

© 2022 Bhagwan Bansal

This repository is licensed under the MIT license. See LICENSE for details.touch